# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['poetry_test']

package_data = \
{'': ['*']}

install_requires = \
['PyJWT[crypto]>=2.3.0,<3.0.0']

setup_kwargs = {
    'name': 'poetry-test',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Grady Barrett',
    'author_email': 'Grady.Barrett@Gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
